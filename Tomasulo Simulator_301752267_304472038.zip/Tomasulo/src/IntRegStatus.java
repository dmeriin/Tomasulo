
public class IntRegStatus {

	int Value;
	int Rob;
	
	public IntRegStatus(int value, int rob) {
		Value = value;
		Rob = rob;
	}
	
	
}
