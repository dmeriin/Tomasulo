
public class Config {
	public int  IntDelay;
	public int	AddDelay;
	public int	MulDelay;
	public int	MemDelay;
	public int	RobEntries; 
	public int	AddNrReservation;
	public int	MulNrReservation;
	public int	IntNrReservation;
	public int	MemNrLoadBuffers;
	public int	MemNrStoreBuffers;

}
