
public class FpRegStatus {

	float Value;
	int Rob;
	public FpRegStatus(float value, int rob) {
		Value = value;
		Rob = rob;
	}
	
	
}
